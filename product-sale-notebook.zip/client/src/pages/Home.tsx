import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Printer, Plus, Calendar, TrendingUp, X } from 'lucide-react';
import { toast } from 'sonner';

interface SaleRecord {
  id: string;
  date: string;
  time: string;
  productName: string;
  quantity: number;
  price: number;
  total: number;
}

interface DailyData {
  date: string;
  records: SaleRecord[];
  total: number;
}

/**
 * Modern Minimalist Ledger Design
 * Typography-first interface with Playfair Display headings and Lato body text
 * Warm sage green accents (#6B8E6F) with cream background and gold totals
 */
export default function Home() {
  const [records, setRecords] = useState<SaleRecord[]>([]);
  const [allData, setAllData] = useState<DailyData[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [showPrint, setShowPrint] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState<string>('');

  // Form state
  const [productName, setProductName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [price, setPrice] = useState('');

  // Get today's date
  const today = new Date().toISOString().split('T')[0];

  // Initialize data from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('saleNotebookData');
    if (saved) {
      const data = JSON.parse(saved);
      setAllData(data);
      // Load today's records
      const todayData = data.find((d: DailyData) => d.date === today);
      if (todayData) {
        setRecords(todayData.records);
      }
    }
    // Set default month to current month
    setSelectedMonth(today.substring(0, 7));
  }, [today]);

  // Save data to localStorage
  const saveData = (newRecords: SaleRecord[]) => {
    const updatedData = [...allData];
    const existingIndex = updatedData.findIndex(d => d.date === today);
    const total = newRecords.reduce((sum, r) => sum + r.total, 0);

    if (existingIndex >= 0) {
      updatedData[existingIndex] = { date: today, records: newRecords, total };
    } else {
      updatedData.push({ date: today, records: newRecords, total });
    }

    updatedData.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    setAllData(updatedData);
    localStorage.setItem('saleNotebookData', JSON.stringify(updatedData));
  };

  // Add new sale record
  const handleAddRecord = () => {
    if (!productName.trim() || !quantity || !price) {
      toast.error('Please fill all fields');
      return;
    }

    const qty = parseFloat(quantity);
    const prc = parseFloat(price);

    if (qty <= 0 || prc <= 0) {
      toast.error('Quantity and price must be greater than 0');
      return;
    }

    const now = new Date();
    const newRecord: SaleRecord = {
      id: Date.now().toString(),
      date: today,
      time: now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true }),
      productName: productName.trim(),
      quantity: qty,
      price: prc,
      total: qty * prc,
    };

    const newRecords = [...records, newRecord];
    setRecords(newRecords);
    saveData(newRecords);

    // Reset form
    setProductName('');
    setQuantity('');
    setPrice('');

    toast.success('Sale recorded successfully');
  };

  // Delete record
  const handleDeleteRecord = (id: string) => {
    const newRecords = records.filter(r => r.id !== id);
    setRecords(newRecords);
    saveData(newRecords);
    toast.success('Record deleted');
  };

  // Calculate totals
  const dailyTotal = records.reduce((sum, r) => sum + r.total, 0);
  const monthlyData = allData.filter(d => d.date.startsWith(selectedMonth));
  const monthlyTotal = monthlyData.reduce((sum, d) => sum + d.total, 0);

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  // Format date
  const formatDate = (dateStr: string) => {
    return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-IN', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-ledger-line bg-white sticky top-0 z-10">
        <div className="container py-6">
          <div className="flex items-baseline justify-between">
            <div>
              <h1 className="text-4xl font-bold text-foreground">Sales Notebook</h1>
              <p className="text-muted-foreground mt-1">Daily product sales record & history</p>
            </div>
            <div className="flex gap-3">
              <Button
                onClick={() => setShowHistory(true)}
                variant="outline"
                className="gap-2"
              >
                <Calendar className="w-4 h-4" />
                History
              </Button>
              <Button
                onClick={() => setShowPrint(true)}
                variant="outline"
                className="gap-2"
              >
                <Printer className="w-4 h-4" />
                Print
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Entry Form & Records */}
          <div className="lg:col-span-2 space-y-8">
            {/* Entry Form */}
            <Card className="p-8 border-ledger-line shadow-sm">
              <h2 className="text-2xl font-bold mb-6 text-foreground">New Sale Entry</h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Product Name
                  </label>
                  <Input
                    type="text"
                    placeholder="Enter product name"
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleAddRecord()}
                    className="border-ledger-line focus:ring-2 focus:ring-accent"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Quantity
                    </label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleAddRecord()}
                      className="border-ledger-line focus:ring-2 focus:ring-accent"
                      step="0.01"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Price (₹)
                    </label>
                    <Input
                      type="number"
                      placeholder="0.00"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleAddRecord()}
                      className="border-ledger-line focus:ring-2 focus:ring-accent"
                      step="0.01"
                    />
                  </div>
                </div>

                <Button
                  onClick={handleAddRecord}
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-6 gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Add Sale Record
                </Button>
              </div>
            </Card>

            {/* Today's Records */}
            <div>
              <div className="flex items-baseline justify-between mb-6">
                <h2 className="text-2xl font-bold text-foreground">Today's Records</h2>
                <p className="text-sm text-muted-foreground">{formatDate(today)}</p>
              </div>

              {records.length === 0 ? (
                <Card className="p-12 text-center border-ledger-line">
                  <p className="text-muted-foreground">No sales recorded today</p>
                </Card>
              ) : (
                <div className="space-y-2 border border-ledger-line rounded-lg overflow-hidden">
                  {/* Table Header */}
                  <div className="grid grid-cols-12 gap-4 px-6 py-4 bg-secondary border-b border-ledger-line font-semibold text-sm">
                    <div className="col-span-1">Time</div>
                    <div className="col-span-4">Product</div>
                    <div className="col-span-2 text-right">Qty</div>
                    <div className="col-span-2 text-right">Price</div>
                    <div className="col-span-2 text-right">Total</div>
                    <div className="col-span-1"></div>
                  </div>

                  {/* Table Rows */}
                  {records.map((record) => (
                    <div
                      key={record.id}
                      className="grid grid-cols-12 gap-4 px-6 py-4 border-b border-ledger-line hover:bg-secondary/50 transition-colors items-center"
                    >
                      <div className="col-span-1 text-sm text-muted-foreground">{record.time}</div>
                      <div className="col-span-4 font-medium">{record.productName}</div>
                      <div className="col-span-2 text-right monospace text-sm">{record.quantity}</div>
                      <div className="col-span-2 text-right monospace text-sm">₹{record.price.toFixed(2)}</div>
                      <div className="col-span-2 text-right monospace font-semibold text-accent">
                        ₹{record.total.toFixed(2)}
                      </div>
                      <div className="col-span-1 flex justify-end">
                        <button
                          onClick={() => handleDeleteRecord(record.id)}
                          className="text-destructive hover:text-destructive/80 transition-colors p-1"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}

                  {/* Total Row */}
                  <div className="grid grid-cols-12 gap-4 px-6 py-4 bg-secondary/30 font-bold">
                    <div className="col-span-9">Today's Total</div>
                    <div className="col-span-3 text-right monospace text-lg text-ledger-gold">
                      ₹{dailyTotal.toFixed(2)}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column - Sidebar Stats */}
          <div className="space-y-6">
            {/* Today's Stats */}
            <Card className="p-6 border-ledger-line shadow-sm">
              <h3 className="text-lg font-bold text-foreground mb-4">Today's Summary</h3>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Sales</p>
                  <p className="text-3xl font-bold monospace text-ledger-gold">
                    ₹{dailyTotal.toFixed(2)}
                  </p>
                </div>
                <div className="border-t border-ledger-line pt-3">
                  <p className="text-sm text-muted-foreground mb-1">Records</p>
                  <p className="text-2xl font-bold text-accent">{records.length}</p>
                </div>
              </div>
            </Card>

            {/* Monthly Stats */}
            <Card className="p-6 border-ledger-line shadow-sm">
              <h3 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-accent" />
                Monthly Summary
              </h3>
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-semibold text-foreground mb-2 block">
                    Select Month
                  </label>
                  <input
                    type="month"
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(e.target.value)}
                    className="w-full px-3 py-2 border border-ledger-line rounded-md text-sm focus:ring-2 focus:ring-accent"
                  />
                </div>
                <div className="border-t border-ledger-line pt-3">
                  <p className="text-sm text-muted-foreground mb-1">Total Sales</p>
                  <p className="text-2xl font-bold monospace text-ledger-gold">
                    ₹{monthlyTotal.toFixed(2)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Days with Sales</p>
                  <p className="text-xl font-bold text-accent">{monthlyData.length}</p>
                </div>
              </div>
            </Card>

            {/* Quick Info */}
            <Card className="p-6 border-ledger-line shadow-sm bg-secondary/30">
              <h3 className="text-sm font-bold text-foreground mb-3">Quick Info</h3>
              <div className="space-y-2 text-sm text-muted-foreground">
                <p>• Auto-saves all entries locally</p>
                <p>• View monthly history anytime</p>
                <p>• Print monthly reports</p>
                <p>• All data stays on your device</p>
              </div>
            </Card>
          </div>
        </div>
      </main>

      {/* History Modal */}
      <Dialog open={showHistory} onOpenChange={setShowHistory}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">Sales History</DialogTitle>
          </DialogHeader>

          <Tabs defaultValue="monthly" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="monthly">Monthly View</TabsTrigger>
              <TabsTrigger value="all">All Records</TabsTrigger>
            </TabsList>

            <TabsContent value="monthly" className="space-y-4 mt-4">
              <div>
                <label className="text-sm font-semibold text-foreground mb-2 block">
                  Select Month
                </label>
                <input
                  type="month"
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className="w-full px-3 py-2 border border-ledger-line rounded-md text-sm focus:ring-2 focus:ring-accent"
                />
              </div>

              {monthlyData.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No records for this month</p>
              ) : (
                <div className="space-y-4">
                  {monthlyData.map((day) => (
                    <div key={day.date} className="border border-ledger-line rounded-lg p-4">
                      <div className="flex justify-between items-center mb-3">
                        <h4 className="font-bold text-foreground">{formatDate(day.date)}</h4>
                        <p className="monospace font-bold text-ledger-gold">₹{day.total.toFixed(2)}</p>
                      </div>
                      <div className="space-y-2 text-sm">
                        {day.records.map((record) => (
                          <div key={record.id} className="flex justify-between text-muted-foreground">
                            <span>{record.productName} × {record.quantity}</span>
                            <span className="monospace">₹{record.total.toFixed(2)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="all" className="space-y-4 mt-4">
              {allData.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No records yet</p>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {allData.map((day) => (
                    <div key={day.date} className="flex justify-between items-center p-3 border border-ledger-line rounded-lg">
                      <div>
                        <p className="font-semibold text-foreground">{formatDate(day.date)}</p>
                        <p className="text-sm text-muted-foreground">{day.records.length} records</p>
                      </div>
                      <p className="monospace font-bold text-ledger-gold">₹{day.total.toFixed(2)}</p>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Print Modal */}
      <Dialog open={showPrint} onOpenChange={setShowPrint}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">Monthly Report</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-semibold text-foreground mb-2 block">
                Select Month
              </label>
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="w-full px-3 py-2 border border-ledger-line rounded-md text-sm focus:ring-2 focus:ring-accent"
              />
            </div>

            {/* Print Preview */}
            <div className="border border-ledger-line rounded-lg p-8 bg-white print:border-0">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-foreground">Sales Report</h2>
                <p className="text-muted-foreground mt-2">
                  {new Date(selectedMonth + '-01').toLocaleDateString('en-IN', {
                    year: 'numeric',
                    month: 'long',
                  })}
                </p>
              </div>

              {monthlyData.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No records for this month</p>
              ) : (
                <div className="space-y-6">
                  {monthlyData.map((day) => (
                    <div key={day.date} className="mb-6">
                      <div className="flex justify-between items-center mb-3 pb-2 border-b-2 border-ledger-line">
                        <h3 className="font-bold text-foreground">{formatDate(day.date)}</h3>
                        <p className="monospace font-bold text-ledger-gold">₹{day.total.toFixed(2)}</p>
                      </div>
                      <div className="space-y-1 text-sm">
                        {day.records.map((record) => (
                          <div key={record.id} className="grid grid-cols-3 gap-4">
                            <div>{record.productName}</div>
                            <div className="text-right">{record.quantity} × ₹{record.price.toFixed(2)}</div>
                            <div className="text-right monospace font-semibold">₹{record.total.toFixed(2)}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}

                  <div className="border-t-2 border-ledger-line pt-4 mt-6">
                    <div className="flex justify-between items-center">
                      <p className="text-lg font-bold text-foreground">Monthly Total</p>
                      <p className="text-2xl monospace font-bold text-ledger-gold">₹{monthlyTotal.toFixed(2)}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <Button
              onClick={() => window.print()}
              className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-6 gap-2"
            >
              <Printer className="w-4 h-4" />
              Print Report
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
